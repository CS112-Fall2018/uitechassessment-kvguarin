import { CartService } from '../cart.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
  providers: [CartService]
})
export class CartComponent implements OnInit {
  title: "cart class"
  items: any = [];

  constructor(private cartService : CartService) { }

  ngOnInit() {
    this.cartService.getAllItems().subscribe(posts =>{
      this.items = posts;
      console.log(posts);
    });
  }

}
