import { CartService, Item } from './../cart.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css'],
  providers: [CartService]
})
export class AddItemComponent implements OnInit {
  title: "add items"
  data: any;
  error: any;
  result: any;

  item: Item = {
    id: "12",
    name: "hello",
    description: "its me",
    price: "0",
    amount: "0"
  };
  
  constructor(private cartService : CartService) { }

  add(thisname :string, description: string, price: string, amount: string): void {
    console.log(thisname);
    console.log(description);
    console.log(price);
    console.log(amount);

    this.item.name = thisname;
    this.item.description = description;
    this.item.price = price;
    this.item.amount = amount;
    this.result = "Successfully added item " + this.item.name + "!";
    this.data = "";

    const requestResult = this.cartService.insertItem(this.item);
    requestResult.subscribe(
      (data) => {
        this.data = data;
        console.log(this.data);
      },
      (error)=>{
        this.error = error;
        this.result = error;
        console.log(this.error);
      }
    );
  
  }
  ngOnInit() {

  }

}
 